//
// Created by Tim Apers on 29/10/2024.
//

#include "Game.h"
#include "Room.h"
#include "fstream"
#include "iostream"
Game::Game(sf::RenderWindow* window) {
    this->window = window;
}

void Game::update() {
    //setCurrentRoom();

    this->window->clear();
    if (currentRoom) { currentRoom->render(this->window); }
    this->window->display();
    while (window->isOpen()) {
        sf::Event event;

        // Wait for event to fire
        while (window->pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window->close();
            } else if (event.type == sf::Event::KeyPressed) {
                currentRoom->update(&event);
                setCurrentRoom();
                this->window->clear();
                currentRoom->render(this->window);
                this->window->display();
            }
        }
    }
}

void Game::loadMap(const std::string& filename) {
    ifstream map(filename);
    string line;

    vector<vector<string>> kamers;
    vector<string> kamerBuffer;

    auto isRoomValid = [](const vector<string>& room) {
        for (const auto& line : room) {
            if (line.find_first_not_of(' ') != string::npos) {
                return true;
            }
        }
        return false;
    };

    // New matrix to store room positions

    int gridX = 0, gridY = 0; // Track positions in the room grid

    if (map.is_open()) {
        while (getline(map, line)) {
            
            // als je een lege lijn tegenkomt is de kamerBuffer ongeldig
            if (line.empty()) {
                kamerBuffer.clear();
                continue;
            }
            // zet de lijn op de buffer kamer
            kamerBuffer.push_back(line);

            //als die een volledige kamer heeft verzameld
            if (kamerBuffer.size() == 7) {
                size_t maxWidth = 0;
                for (const auto& kamerBufferLine : kamerBuffer) {
                    maxWidth = max(maxWidth, kamerBufferLine.length());
                }

                for (size_t colStart = 0; colStart + 7 <= maxWidth; colStart += 7) {
                    vector<string> room;
                    for (const auto& kamerBufferLine : kamerBuffer) {
                        if (colStart + 7 <= kamerBufferLine.length()) {
                            room.push_back(kamerBufferLine.substr(colStart, 7));
                        }
                    }

                    if (room.size() == 7 && isRoomValid(room)) {
                        kamers.push_back(room);
                        // Store room index in roomGrid
                        roomGrid[gridY][gridX] = kamers.size() - 1; // Use room index
                    }
                    gridX++; // Move to next column in the grid
                }

                kamerBuffer.clear();
                gridX = 0; // Reset X for next set of rooms
                gridY++;   // Move to next row in the grid
            }
        }
        map.close();

        for (int indexRooms = 0; indexRooms < kamers.size(); indexRooms++) {
            Room* kamer = new Room;

            for (int indexroomsize = 0; indexroomsize < kamers[indexRooms].size(); indexroomsize++) {
                for (int indexline = 0; indexline < kamers[indexRooms][indexroomsize].size(); indexline++) {
                    Entity* entity = nullptr;
                    Player* playerentity = nullptr;
                    switch (kamers[indexRooms][indexroomsize][indexline]) {
                        case '#':
                            entity = new Wall();
                            entity->setSprite("resources/wall.png");
                            break;
                        case '@':
                            entity = new Floor();
                            entity->setSprite("resources/floor.png");
                            if (indexRooms == 2) {
                                entity->setPosition({(indexline * 100) + (700), indexroomsize * 100 + (700)});
                            } else {
                                entity->setPosition({indexline * 100, indexroomsize * 100 + (indexRooms * 700)});
                            }
                            kamer->addEntity(entity);

                            playerentity = new Player();
                            playerentity->setSprite("resources/player.png");
                            kamer->playerptr = playerentity;
                            break;
                        case '!':
                            entity = new Weapon();
                            entity->setSprite("resources/weapon.png");
                            break;
                        case '%':
                            entity = new Enemy();
                            entity->setSprite("resources/enemy.png");
                            break;
                        case '_':
                            entity = new Floor();
                            entity->setSprite("resources/floor.png");
                            break;
                    }

                    if (entity != nullptr) {
                        if (indexRooms == 2) {
                            entity->setPosition({(indexline * 100) + (700), indexroomsize * 100 + (700)});
                        } else {
                            entity->setPosition({indexline * 100, indexroomsize * 100 + (indexRooms * 700)});
                        }
                        kamer->addEntity(entity);
                        if(playerentity != nullptr){
                            if (indexRooms == 2) {
                                playerentity->setPosition({(indexline * 100) + (700), indexroomsize * 100 + (700)});
                            } else {
                                playerentity->setPosition({indexline * 100, indexroomsize * 100 + (indexRooms * 700)});
                            }
                            kamer->addEntity(playerentity);
                        }
                    }
                }
            }
            this->rooms.push_back(kamer);
        }
    }

    currentRoom = rooms[1];
    //het x coordinaat van de kamer in de matrix van de indeling van de kamers.
    get<0>(currentRoomMatrix) = 0;
    //het x coordinaat van de kamer in de matrix van de indeling van de kamers.
    get<1>(currentRoomMatrix) = 1;

}


void Game::setCurrentRoom() {
    // Controleer of de speler boven de huidige kamergrens zit
    if (currentRoom->playerptr->getPosition().y < (std::get<1>(currentRoomMatrix) * 700)) {
        get<1>(currentRoomMatrix) -= 1; // Verplaats naar de kamer hierboven

    } else if (currentRoom->playerptr->getPosition().y >= ((std::get<1>(currentRoomMatrix) + 1) * 700)) {
        get<1>(currentRoomMatrix) += 1; // Verplaats naar de kamer hieronder
    } else if (currentRoom->playerptr->getPosition().x < (std::get<0>(currentRoomMatrix) * 700)) {
        get<0>(currentRoomMatrix) -= 1; // Verplaats naar de kamer hierboven
    }else if (currentRoom->playerptr->getPosition().x >= ((std::get<0>(currentRoomMatrix) + 1) * 700)) {
        get<0>(currentRoomMatrix) += 1; // Verplaats naar de kamer hierboven
    }else {
        return; // Geen verandering nodig
    }

    // Verplaats de speler naar de nieuwe kamer
    Room* oldRoom = currentRoom;
    currentRoom = rooms[roomGrid[get<1>(currentRoomMatrix)][std::get<0>(currentRoomMatrix)]];
    currentRoom->addEntity(oldRoom->playerptr);
    oldRoom->removeEntity(oldRoom->playerptr);
}

